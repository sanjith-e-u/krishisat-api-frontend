"use client"

import { useState } from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import {
  Check,
  Copy,
  ArrowRight,
  Terminal,
  Key,
  MapPin,
  Leaf,
  CloudRain,
  Code2,
} from "lucide-react"

export default function QuickstartPage() {
  const [copiedBlock, setCopiedBlock] = useState<string | null>(null)

  const handleCopy = (id: string, text: string) => {
    void navigator.clipboard.writeText(text).catch(() => {})
    setCopiedBlock(id)
    setTimeout(() => setCopiedBlock(null), 2000)
  }

  return (
    <div className="bg-[#F8FAFC] min-h-screen">
      <div className="max-w-2xl mx-auto px-6 py-16">
        {/* SECTION 1 — BREADCRUMB */}
        <div className="flex items-center gap-2 text-sm text-[#64748B] mb-8">
          <Link
            href="/developers"
            className="hover:text-[#2563EB] transition-colors focus:outline-none focus:ring-2 focus:ring-[#2563EB] rounded px-1"
          >
            Developers
          </Link>
          <span className="text-[#E2E8F0]">/</span>
          <span className="text-[#0F172A] font-medium">Quickstart</span>
        </div>

        {/* SECTION 2 — HERO */}
        <div className="mb-16">
          <span className="text-[10px] uppercase tracking-widest font-mono text-[#2563EB] mb-4 block">
            Quickstart
          </span>
          <h1 className="text-4xl font-bold tracking-tight text-[#0F172A] mb-4">
            Make your first API request
          </h1>
          <p className="text-lg text-[#64748B] leading-relaxed mb-8 max-w-xl">
            Register a farm polygon, request vegetation indices, and get hyperlocal
            weather data. This guide takes under 2 minutes.
          </p>
          <div className="flex items-center gap-3 flex-wrap">
            <Link
              href="/docs"
              className="bg-[#2563EB] hover:bg-[#1d4ed8] text-white px-6 py-3 rounded-lg text-sm font-medium transition-colors shadow-sm inline-flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:ring-offset-2"
            >
              View Documentation <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/developers"
              className="border border-[#E2E8F0] hover:border-[#2563EB] text-[#0F172A] hover:text-[#2563EB] px-6 py-3 rounded-lg text-sm font-medium transition-colors bg-transparent focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:ring-offset-2"
            >
              Get API Key
            </Link>
          </div>
        </div>

        {/* SECTION 3 — STEP 1 */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#2563EB] text-white text-sm font-bold font-mono shrink-0">
              1
            </span>
            <div>
              <span className="text-[10px] uppercase tracking-widest font-mono text-[#64748B] block">
                Step 1
              </span>
              <h2 className="text-lg font-bold tracking-tight text-[#0F172A]">
                Get an API Key
              </h2>
            </div>
          </div>

          <div className="ml-11">
            <p className="text-[#64748B] leading-relaxed mb-4">
              Generate a free Sandbox API key from the developer dashboard. Store it
              as an environment variable — never hardcode it in your application.
            </p>

            <div className="relative group mb-6">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-800 rounded-t-lg border-b border-slate-700">
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
                  env
                </span>
                <button
                  onClick={() => handleCopy("step1-env", "KSAT_API_KEY=ks_test_xxxxxxxxxxxx")}
                  aria-label="Copy code"
                  className={cn(
                    "flex items-center gap-1.5 text-xs transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-1 rounded px-1",
                    copiedBlock === "step1-env"
                      ? "text-emerald-400"
                      : "text-slate-400 hover:text-white"
                  )}
                >
                  {copiedBlock === "step1-env" ? (
                    <><Check className="w-3.5 h-3.5" /><span>Copied</span></>
                  ) : (
                    <><Copy className="w-3.5 h-3.5" /><span>Copy</span></>
                  )}
                </button>
              </div>
              <pre className="bg-[#0D1117] rounded-b-lg p-4 overflow-x-auto font-mono text-xs leading-relaxed whitespace-pre">
                <code>
                  <span className="text-slate-400">KSAT_API_KEY</span>
                  <span className="text-slate-600">=</span>
                  <span className="text-emerald-400">ks_test_xxxxxxxxxxxx</span>
                </code>
              </pre>
            </div>

            <div className="flex gap-3 p-4 bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg mt-4">
              <Key className="w-4 h-4 text-[#2563EB] shrink-0 mt-0.5" aria-hidden="true" />
              <p className="text-xs text-[#64748B] leading-relaxed">
                Sandbox keys are prefixed with{" "}
                <code className="font-mono text-xs bg-white border border-[#E2E8F0] px-1 rounded text-[#2563EB]">
                  ks_test_
                </code>
                . Production keys use{" "}
                <code className="font-mono text-xs bg-white border border-[#E2E8F0] px-1 rounded text-[#2563EB]">
                  ks_live_
                </code>
                . The Sandbox tier is free with 1,000 calls per month.
              </p>
            </div>
          </div>
        </div>

        {/* SECTION 4 — STEP 2 */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#2563EB] text-white text-sm font-bold font-mono shrink-0">
              2
            </span>
            <div>
              <span className="text-[10px] uppercase tracking-widest font-mono text-[#64748B] block">
                Step 2
              </span>
              <h2 className="text-lg font-bold tracking-tight text-[#0F172A] inline-flex items-center gap-2">
                Register a Farm <MapPin className="w-4 h-4 text-[#2563EB] shrink-0" aria-hidden="true" />
              </h2>
            </div>
          </div>

          <div className="ml-11">
            <p className="text-[#64748B] leading-relaxed mb-4">
              Register your farm polygon once to receive a stable{" "}
              <code className="font-mono text-xs bg-[#F8FAFC] border border-[#E2E8F0] px-1 rounded text-[#2563EB]">
                farm_id
              </code>
              . This ID is used in every subsequent API call.
            </p>

            <div className="relative group mb-6">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-800 rounded-t-lg border-b border-slate-700">
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
                  bash
                </span>
                <button
                  onClick={() => handleCopy("step2-curl", `curl -X POST https://api.krishisat.dev/v1/farms \\\n  -H "Authorization: Bearer $KSAT_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"farm_name":"My Farm","polygon":{...GeoJSON...}}'`)}
                  aria-label="Copy code"
                  className={cn(
                    "flex items-center gap-1.5 text-xs transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-1 rounded px-1",
                    copiedBlock === "step2-curl"
                      ? "text-emerald-400"
                      : "text-slate-400 hover:text-white"
                  )}
                >
                  {copiedBlock === "step2-curl" ? (
                    <><Check className="w-3.5 h-3.5" /><span>Copied</span></>
                  ) : (
                    <><Copy className="w-3.5 h-3.5" /><span>Copy</span></>
                  )}
                </button>
              </div>
              <pre className="bg-[#0D1117] rounded-b-lg p-4 overflow-x-auto font-mono text-xs leading-relaxed whitespace-pre">
                <code>
                  <span className="text-rose-400">curl</span>
                  <span className="text-slate-400"> -X </span>
                  <span className="text-white">POST </span>
                  <span className="text-cyan-400">https://api.krishisat.dev/v1/farms</span>
                  <span className="text-white"> \</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">-H </span>
                  <span className="text-emerald-400">"Authorization: Bearer $KSAT_API_KEY"</span>
                  <span className="text-white"> \</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">-H </span>
                  <span className="text-emerald-400">"Content-Type: application/json"</span>
                  <span className="text-white"> \</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">-d </span>
                  <span className="text-emerald-400">{'\'{"farm_name":"My Farm","polygon":{...GeoJSON...}}\''}</span>
                </code>
              </pre>
            </div>

            <div className="relative group mt-4 mb-0">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-800 rounded-t-lg border-b border-slate-700">
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
                  json
                </span>
                <button
                  onClick={() => handleCopy("step2-response", `{\n  "farm_id": "farm_001",\n  "status": "registered",\n  "created_at": "2026-06-11T10:00:00Z"\n}`)}
                  aria-label="Copy code"
                  className={cn(
                    "flex items-center gap-1.5 text-xs transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-1 rounded px-1",
                    copiedBlock === "step2-response"
                      ? "text-emerald-400"
                      : "text-slate-400 hover:text-white"
                  )}
                >
                  {copiedBlock === "step2-response" ? (
                    <><Check className="w-3.5 h-3.5" /><span>Copied</span></>
                  ) : (
                    <><Copy className="w-3.5 h-3.5" /><span>Copy</span></>
                  )}
                </button>
              </div>
              <pre className="bg-[#0D1117] rounded-b-lg p-4 overflow-x-auto font-mono text-xs leading-relaxed whitespace-pre">
                <code>
                  <span className="text-slate-600">{"{"}</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"farm_id"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-emerald-400">"farm_001"</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"status"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-emerald-400">"registered"</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"created_at"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-emerald-400">"2026-06-11T10:00:00Z"</span>{"\n"}
                  <span className="text-slate-600">{"}"}</span>
                </code>
              </pre>
            </div>

            <div className="flex gap-3 p-4 bg-emerald-50 border border-emerald-200 rounded-lg mt-4">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" aria-hidden="true" />
              <p className="text-xs text-emerald-800 leading-relaxed">
                Save your{" "}
                <code className="font-mono bg-emerald-100 px-1 rounded text-emerald-900">
                  farm_id
                </code>
                . You will use it in every subsequent API call.
              </p>
            </div>
          </div>
        </div>

        {/* SECTION 5 — STEP 3 */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#2563EB] text-white text-sm font-bold font-mono shrink-0">
              3
            </span>
            <div>
              <span className="text-[10px] uppercase tracking-widest font-mono text-[#64748B] block">
                Step 3
              </span>
              <h2 className="text-lg font-bold tracking-tight text-[#0F172A] inline-flex items-center gap-2">
                Request Crop Health (NDVI) <Leaf className="w-4 h-4 text-[#2563EB] shrink-0" aria-hidden="true" />
              </h2>
            </div>
          </div>

          <div className="ml-11">
            <p className="text-[#64748B] leading-relaxed mb-4">
              Call the NDVI endpoint using your{" "}
              <code className="font-mono text-xs bg-[#F8FAFC] border border-[#E2E8F0] px-1 rounded text-[#2563EB]">
                farm_id
              </code>
              . The response includes a vegetation index score and a human-readable
              health status.
            </p>

            <div className="relative group mb-6">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-800 rounded-t-lg border-b border-slate-700">
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
                  bash
                </span>
                <button
                  onClick={() => handleCopy("step3-curl", `curl -X POST https://api.krishisat.dev/v1/vegetation/ndvi \\\n  -H "Authorization: Bearer $KSAT_API_KEY" \\\n  -d '{"farm_id":"farm_001"}'`)}
                  aria-label="Copy code"
                  className={cn(
                    "flex items-center gap-1.5 text-xs transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-1 rounded px-1",
                    copiedBlock === "step3-curl"
                      ? "text-emerald-400"
                      : "text-slate-400 hover:text-white"
                  )}
                >
                  {copiedBlock === "step3-curl" ? (
                    <><Check className="w-3.5 h-3.5" /><span>Copied</span></>
                  ) : (
                    <><Copy className="w-3.5 h-3.5" /><span>Copy</span></>
                  )}
                </button>
              </div>
              <pre className="bg-[#0D1117] rounded-b-lg p-4 overflow-x-auto font-mono text-xs leading-relaxed whitespace-pre">
                <code>
                  <span className="text-rose-400">curl</span>
                  <span className="text-slate-400"> -X </span>
                  <span className="text-white">POST </span>
                  <span className="text-cyan-400">https://api.krishisat.dev/v1/vegetation/ndvi</span>
                  <span className="text-white"> \</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">-H </span>
                  <span className="text-emerald-400">"Authorization: Bearer $KSAT_API_KEY"</span>
                  <span className="text-white"> \</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">-d </span>
                  <span className="text-emerald-400">{'\'{"farm_id":"farm_001"}\''}</span>
                </code>
              </pre>
            </div>

            <div className="relative group mt-4 mb-0">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-800 rounded-t-lg border-b border-slate-700">
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
                  json
                </span>
                <button
                  onClick={() => handleCopy("step3-response", `{\n  "farm_id": "farm_001",\n  "ndvi": 0.82,\n  "health": "Healthy",\n  "date": "2026-06-11"\n}`)}
                  aria-label="Copy code"
                  className={cn(
                    "flex items-center gap-1.5 text-xs transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-1 rounded px-1",
                    copiedBlock === "step3-response"
                      ? "text-emerald-400"
                      : "text-slate-400 hover:text-white"
                  )}
                >
                  {copiedBlock === "step3-response" ? (
                    <><Check className="w-3.5 h-3.5" /><span>Copied</span></>
                  ) : (
                    <><Copy className="w-3.5 h-3.5" /><span>Copy</span></>
                  )}
                </button>
              </div>
              <pre className="bg-[#0D1117] rounded-b-lg p-4 overflow-x-auto font-mono text-xs leading-relaxed whitespace-pre">
                <code>
                  <span className="text-slate-600">{"{"}</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"farm_id"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-emerald-400">"farm_001"</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"ndvi"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-amber-400">0.82</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"health"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-emerald-400">"Healthy"</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"date"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-emerald-400">"2026-06-11"</span>{"\n"}
                  <span className="text-slate-600">{"}"}</span>
                </code>
              </pre>
            </div>

            <p className="text-xs text-[#64748B] mt-3 leading-relaxed">
              NDVI values range from <span className="font-mono text-[#0F172A]">-1</span> to{" "}
              <span className="font-mono text-[#0F172A]">+1</span>. Values above{" "}
              <span className="font-mono text-[#0F172A]">0.6</span> indicate healthy
              vegetation. This call costs <span className="font-mono text-[#0F172A]">2 credits</span>.
            </p>
          </div>
        </div>

        {/* SECTION 6 — STEP 4 */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#2563EB] text-white text-sm font-bold font-mono shrink-0">
              4
            </span>
            <div>
              <span className="text-[10px] uppercase tracking-widest font-mono text-[#64748B] block">
                Step 4
              </span>
              <h2 className="text-lg font-bold tracking-tight text-[#0F172A] inline-flex items-center gap-2">
                Get Hyperlocal Weather <CloudRain className="w-4 h-4 text-[#2563EB] shrink-0" aria-hidden="true" />
              </h2>
            </div>
          </div>

          <div className="ml-11">
            <p className="text-[#64748B] leading-relaxed mb-4">
              Request hyperlocal weather data for your registered farm. This endpoint
              returns temperature, rainfall, humidity, wind speed, and growing degree
              days.
            </p>

            <div className="relative group mb-6">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-800 rounded-t-lg border-b border-slate-700">
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
                  bash
                </span>
                <button
                  onClick={() => handleCopy("step4-curl", `curl -X POST https://api.krishisat.dev/v1/weather \\\n  -H "Authorization: Bearer $KSAT_API_KEY" \\\n  -d '{"farm_id":"farm_001"}'`)}
                  aria-label="Copy code"
                  className={cn(
                    "flex items-center gap-1.5 text-xs transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-1 rounded px-1",
                    copiedBlock === "step4-curl"
                      ? "text-emerald-400"
                      : "text-slate-400 hover:text-white"
                  )}
                >
                  {copiedBlock === "step4-curl" ? (
                    <><Check className="w-3.5 h-3.5" /><span>Copied</span></>
                  ) : (
                    <><Copy className="w-3.5 h-3.5" /><span>Copy</span></>
                  )}
                </button>
              </div>
              <pre className="bg-[#0D1117] rounded-b-lg p-4 overflow-x-auto font-mono text-xs leading-relaxed whitespace-pre">
                <code>
                  <span className="text-rose-400">curl</span>
                  <span className="text-slate-400"> -X </span>
                  <span className="text-white">POST </span>
                  <span className="text-cyan-400">https://api.krishisat.dev/v1/weather</span>
                  <span className="text-white"> \</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">-H </span>
                  <span className="text-emerald-400">"Authorization: Bearer $KSAT_API_KEY"</span>
                  <span className="text-white"> \</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">-d </span>
                  <span className="text-emerald-400">{'\'{"farm_id":"farm_001"}\''}</span>
                </code>
              </pre>
            </div>

            <div className="relative group mt-4 mb-0">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-800 rounded-t-lg border-b border-slate-700">
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
                  json
                </span>
                <button
                  onClick={() => handleCopy("step4-response", `{\n  "farm_id": "farm_001",\n  "temperature": 29,\n  "rainfall": 12,\n  "humidity": 74,\n  "wind_speed": 14,\n  "growing_degree_days": 8.4,\n  "updated_at": "2026-06-11T10:00:00Z"\n}`)}
                  aria-label="Copy code"
                  className={cn(
                    "flex items-center gap-1.5 text-xs transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-1 rounded px-1",
                    copiedBlock === "step4-response"
                      ? "text-emerald-400"
                      : "text-slate-400 hover:text-white"
                  )}
                >
                  {copiedBlock === "step4-response" ? (
                    <><Check className="w-3.5 h-3.5" /><span>Copied</span></>
                  ) : (
                    <><Copy className="w-3.5 h-3.5" /><span>Copy</span></>
                  )}
                </button>
              </div>
              <pre className="bg-[#0D1117] rounded-b-lg p-4 overflow-x-auto font-mono text-xs leading-relaxed whitespace-pre">
                <code>
                  <span className="text-slate-600">{"{"}</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"farm_id"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-emerald-400">"farm_001"</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"temperature"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-amber-400">29</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"rainfall"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-amber-400">12</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"humidity"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-amber-400">74</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"wind_speed"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-amber-400">14</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"growing_degree_days"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-amber-400">8.4</span>
                  <span className="text-slate-600">,</span>{"\n"}
                  {"  "}
                  <span className="text-slate-400">"updated_at"</span>
                  <span className="text-slate-600">: </span>
                  <span className="text-emerald-400">"2026-06-11T10:00:00Z"</span>{"\n"}
                  <span className="text-slate-600">{"}"}</span>
                </code>
              </pre>
            </div>

            <div className="flex gap-3 p-4 bg-emerald-50 border border-emerald-200 rounded-lg mt-4">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" aria-hidden="true" />
              <p className="text-xs text-emerald-800 leading-relaxed">
                You have made your first 4 KrishiSat API calls. You are ready to
                integrate into your application.
              </p>
            </div>
          </div>
        </div>

        {/* SECTION 7 — SDK PREVIEW */}
        <div className="mb-6 mt-16">
          <span className="text-[10px] uppercase tracking-widest font-mono text-[#64748B] mb-2 block">
            SDKs
          </span>
          <h2 className="text-xl font-bold tracking-tight text-[#0F172A] mb-2">
            Client Libraries
          </h2>
          <p className="text-sm text-[#64748B] leading-relaxed">
            Native SDK support is coming. Until then, use the REST API directly
            with any HTTP client.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Card 1 — Python SDK */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg p-5 custom-shadow">
            <div className="flex items-center justify-between mb-3">
              <Code2 className="w-5 h-5 text-[#64748B]" aria-hidden="true" />
              <span className="text-[10px] font-mono bg-slate-100 text-slate-400 px-1.5 py-0.5 rounded uppercase tracking-wide">
                Soon
              </span>
            </div>
            <h4 className="text-sm font-bold text-[#0F172A] mb-1">Python SDK</h4>
            <p className="text-xs text-[#64748B] leading-relaxed">
              pip install krishisat
            </p>
          </div>

          {/* Card 2 — Node.js SDK */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg p-5 custom-shadow">
            <div className="flex items-center justify-between mb-3">
              <Code2 className="w-5 h-5 text-[#64748B]" aria-hidden="true" />
              <span className="text-[10px] font-mono bg-slate-100 text-slate-400 px-1.5 py-0.5 rounded uppercase tracking-wide">
                Soon
              </span>
            </div>
            <h4 className="text-sm font-bold text-[#0F172A] mb-1">Node.js SDK</h4>
            <p className="text-xs text-[#64748B] leading-relaxed">
              npm install krishisat
            </p>
          </div>

          {/* Card 3 — REST API (featured) */}
          <div className="bg-white border-2 border-[#2563EB] rounded-lg p-5 custom-shadow">
            <div className="flex items-center justify-between mb-3">
              <Terminal className="w-5 h-5 text-[#2563EB]" aria-hidden="true" />
              <span className="text-[10px] font-mono bg-[#2563EB] text-white px-1.5 py-0.5 rounded uppercase tracking-wide">
                Live
              </span>
            </div>
            <h4 className="text-sm font-bold text-[#0F172A] mb-1">REST API</h4>
            <p className="text-xs text-[#64748B] leading-relaxed">
              Available now. Use any HTTP client.
            </p>
          </div>
        </div>

        {/* SECTION 8 — FINAL CTA */}
        <div className="mt-16 bg-[#0F172A] rounded-lg p-8 text-center">
          <span className="text-[10px] uppercase tracking-widest font-mono text-slate-500 mb-3 block">
            What&apos;s Next
          </span>
          <h2 className="text-2xl font-bold tracking-tight text-white mb-3">
            Ready to build?
          </h2>
          <p className="text-sm text-slate-400 leading-relaxed mb-6 max-w-sm mx-auto">
            Explore the full API reference for all 8 endpoints, request schemas,
            response formats, and error codes.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <Link
              href="/developers/reference"
              className="bg-[#2563EB] hover:bg-[#1d4ed8] text-white px-6 py-3 rounded-lg text-sm font-medium transition-colors shadow-sm inline-flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:ring-offset-2"
            >
              Explore API Reference <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/docs"
              className="border border-slate-600 hover:border-slate-400 text-slate-300 hover:text-white px-6 py-3 rounded-lg text-sm font-medium transition-colors bg-transparent focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2"
            >
              Back to Docs
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
