import React from "react";
import Link from "next/link";
import {
  Zap,
  BookOpen,
  Code,
  Terminal,
  Activity,
  ArrowRight
} from "lucide-react";
import { cn } from "@/lib/utils";

interface DevCardProps {
  title: string;
  description: string;
  cta: string;
  icon: React.ReactNode;
  accentClass?: string;
  statusText?: string;
}

function DevCard({ title, description, cta, icon, accentClass, statusText }: DevCardProps) {
  return (
    <div
      className={cn(
        "bg-white border border-[#E2E8F0] rounded-lg p-8 flex flex-col justify-between custom-shadow transition-all duration-200 group hover:border-slate-300",
        accentClass
      )}
    >
      <div>
        <div className="flex justify-between items-start mb-6">
          <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg inline-block">
            {icon}
          </div>
          {statusText && (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-medium bg-emerald-50 text-emerald-700 border border-emerald-100 animate-pulse">
              {statusText}
            </span>
          )}
        </div>
        <h3 className="text-lg font-bold text-[#0F172A] mb-3 tracking-tight">
          {title}
        </h3>
        <p className="text-[#64748B] text-xs sm:text-sm leading-relaxed mb-8">
          {description}
        </p>
      </div>

      {title === "Quick Start" ? (
        <button
          aria-label="Quick Start Guide"
          className="text-[#2563EB] hover:text-[#1d4ed8] text-sm font-semibold inline-flex items-center gap-1.5 transition-colors mt-auto group-hover:translate-x-0.5 duration-200"
        >
          {cta} <ArrowRight className="w-4 h-4" />
        </button>
      ) : (
        <span className="text-slate-400 text-sm font-semibold inline-flex items-center gap-1.5 mt-auto select-none">
          {cta} <ArrowRight className="w-4 h-4" />
          <span className="ml-2 text-[10px] font-mono bg-slate-100 text-slate-400 px-1.5 py-0.5 rounded uppercase tracking-wide">Soon</span>
        </span>
      )}
    </div>
  );
}

export default function Developers() {
  return (
    <div className="bg-[#F8FAFC] min-h-screen py-16">
      <div className="max-w-7xl mx-auto px-6">
        {/* Page Header */}
        <div className="text-left max-w-2xl mb-16 pb-12 border-b border-[#E2E8F0]">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0F172A] tracking-tight mb-3">
            Built for developers.
          </h1>
          <p className="text-[#64748B] text-sm sm:text-base leading-relaxed">
            Everything you need to integrate agricultural intelligence and telemetry into your platforms in minutes.
          </p>
        </div>

        {/* 5 Entry Point Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Card 1: Quick Start */}
          <DevCard
            title="Quick Start"
            description="From zero to first API response in under 3 minutes. Step-by-step guides using SDKs or direct HTTP endpoints."
            cta="Get started"
            accentClass="border-l-[3px] border-l-[#2563EB]"
            icon={<Zap className="w-5 h-5 text-[#2563EB]" />}
          />

          {/* Card 2: Documentation */}
          <DevCard
            title="Documentation"
            description="Full guides for every endpoint, indices math formula reference, caching rules, and payload lifecycle triggers."
            cta="Read the docs"
            icon={<BookOpen className="w-5 h-5 text-slate-500" />}
          />

          {/* Card 3: API Reference */}
          <DevCard
            title="API Reference"
            description="Complete OpenAPI reference detailing request parameters, payloads, responses, errors, and rates."
            cta="View reference"
            accentClass="border-l-[3px] border-l-[#06B6D4]"
            icon={<Code className="w-5 h-5 text-[#06B6D4]" />}
          />

          {/* Card 4: Playground */}
          <DevCard
            title="Playground"
            description="Interactive sandbox to test endpoints live. Query real geospatial polygons without writing a line of code."
            cta="Open playground"
            icon={<Terminal className="w-5 h-5 text-slate-500" />}
          />

          {/* Card 5: Status */}
          <DevCard
            title="Status"
            description="Real-time performance stats, network incidents history, maintenance windows, and SLA metrics."
            cta="View status"
            statusText="● Operational"
            icon={<Activity className="w-5 h-5 text-emerald-500" />}
          />
        </div>
      </div>
    </div>
  );
}
