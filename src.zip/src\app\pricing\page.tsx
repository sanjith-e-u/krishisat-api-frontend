"use client";

import React, { useState } from "react";
import Link from "next/link";
import { ChevronDown, HelpCircle } from "lucide-react";

const faqItems = [
  {
    question: "What happens when my credits run out?",
    answer: "On the Sandbox plan, calls will be rate-limited until the start of the next billing cycle. On the Pro plan, we enable automatic credit refills in increments of $10, or you can opt to cap your usage to prevent unexpected charges."
  },
  {
    question: "Can I switch plans mid-month?",
    answer: "Yes, you can upgrade to Pro or contract for custom Enterprise volumes at any point during your billing cycle. Adjustments are prorated, and your existing credits are automatically pooled into the new plan tier."
  },
  {
    question: "Is there a free trial for the Pro plan?",
    answer: "Yes. When you upgrade to the Pro plan, we credit your account with $20 in developer credits (equivalent to 5,000 standard API calls) for the first month to let you test production workloads risk-free."
  }
];

const pricingTable = [
  { api: "NDVI", credits: "2 credits", cost: "$0.008" },
  { api: "NDRE", credits: "2 credits", cost: "$0.008" },
  { api: "SAVI", credits: "2 credits", cost: "$0.008" },
  { api: "CI", credits: "3 credits", cost: "$0.012" },
  { api: "NDMI", credits: "2 credits", cost: "$0.008" },
  { api: "NDWI", credits: "2 credits", cost: "$0.008" },
  { api: "Weather", credits: "1 credit", cost: "$0.004" },
  { api: "Farm Registration", credits: "1 credit", cost: "$0.004" },
];

export default function Pricing() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  return (
    <div className="bg-[#F8FAFC] min-h-screen py-16">
      <div className="max-w-7xl mx-auto px-6">
        {/* Page Header */}
        <div className="text-center max-w-xl mx-auto mb-16">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0F172A] tracking-tight mb-3">
            Simple, transparent pricing.
          </h1>
          <p className="text-[#64748B] text-sm sm:text-base">
            Start free, scale as you grow. Pay only for the telemetry your application calls.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch mb-24">
          {/* Sandbox */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg p-8 flex flex-col justify-between custom-shadow relative">
            <div>
              <h3 className="text-lg font-bold text-[#0F172A] mb-1 font-mono uppercase tracking-wide">Sandbox</h3>
              <p className="text-xs text-slate-500 mb-6 font-mono">DEVELOPER TESTING</p>
              <div className="flex items-baseline gap-1 my-6 pb-6 border-b border-[#E2E8F0]">
                <span className="text-4xl font-extrabold text-[#0F172A] tracking-tight">Free</span>
              </div>
              <ul className="flex flex-col gap-4 text-sm text-slate-600 mb-8">
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-semibold">✓</span> 5 registered farms
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-semibold">✓</span> Core vegetation indices
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-semibold">✓</span> 1,000 API calls / month
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-semibold">✓</span> Community support
                </li>
                <li className="flex items-center gap-2 text-slate-400 line-through">
                  <span>✗</span> Custom data cadence
                </li>
              </ul>
            </div>
            <Link href="/developers" className="w-full text-center border border-slate-300 hover:border-slate-500 text-slate-700 font-medium py-2.5 rounded-lg text-sm transition-colors mt-auto">
              Start for Free →
            </Link>
          </div>

          {/* Pro */}
          <div className="bg-white border-2 border-[#2563EB] rounded-lg p-8 flex flex-col justify-between custom-shadow relative">
            <span className="bg-[#2563EB] text-white text-[10px] uppercase font-mono font-semibold px-2 py-0.5 rounded absolute top-4 right-4">
              Most Popular
            </span>
            <div>
              <h3 className="text-lg font-bold text-[#0F172A] mb-1 font-mono uppercase tracking-wide">Pro</h3>
              <p className="text-xs text-slate-500 mb-6 font-mono">PRODUCTION DEPLOYMENTS</p>
              <div className="flex items-baseline gap-1 my-6 pb-6 border-b border-[#E2E8F0]">
                <span className="text-4xl font-extrabold text-[#0F172A] tracking-tight">$0.004</span>
                <span className="text-slate-500 font-mono text-sm">/ credit</span>
              </div>
              <ul className="flex flex-col gap-4 text-sm text-slate-600 mb-8">
                <li className="flex items-center gap-2">
                  <span className="text-[#2563EB] font-semibold">✓</span> Unlimited farms
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-[#2563EB] font-semibold">✓</span> Full API access
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-[#2563EB] font-semibold">✓</span> Pooled credit model
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-[#2563EB] font-semibold">✓</span> Email support + SLA
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-[#2563EB] font-semibold">✓</span> Usage analytics dashboard
                </li>
              </ul>
            </div>
            <Link href="/developers" className="w-full text-center bg-[#2563EB] hover:bg-[#1d4ed8] text-white font-medium py-2.5 rounded-lg text-sm transition-colors mt-auto shadow-sm">
              Start Building →
            </Link>
          </div>

          {/* Enterprise */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg p-8 flex flex-col justify-between custom-shadow relative">
            <div>
              <h3 className="text-lg font-bold text-[#0F172A] mb-1 font-mono uppercase tracking-wide">Enterprise</h3>
              <p className="text-xs text-slate-500 mb-6 font-mono">CUSTOM PLATFORMS</p>
              <div className="flex items-baseline gap-1 my-6 pb-6 border-b border-[#E2E8F0]">
                <span className="text-4xl font-extrabold text-[#0F172A] tracking-tight">Custom</span>
              </div>
              <ul className="flex flex-col gap-4 text-sm text-slate-600 mb-8">
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-semibold">✓</span> Volume pricing discounts
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-semibold">✓</span> Dedicated uptime SLA
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-semibold">✓</span> VPC / private cloud deployment
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-semibold">✓</span> Custom data cadence & orbiters
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-semibold">✓</span> Dedicated support team
                </li>
              </ul>
            </div>
            <Link href="/trust" className="w-full text-center border border-slate-300 hover:border-slate-500 text-slate-700 font-medium py-2.5 rounded-lg text-sm transition-colors mt-auto">
              Contact Sales →
            </Link>
          </div>
        </div>

        {/* Credit Pricing Table */}
        <div className="mb-24">
          <div className="text-left mb-8">
            <h2 className="text-xl font-bold text-[#0F172A] tracking-tight">Credit Pricing Table</h2>
            <p className="text-xs text-slate-500 mt-1">
              Estimate your monthly consumption based on API endpoint weight. Each call debits credits from your pool.
            </p>
          </div>
          
          <div className="border border-[#E2E8F0] rounded-lg overflow-hidden bg-white custom-shadow">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-[#E2E8F0] text-xs font-mono text-slate-600 uppercase tracking-wider">
                  <th className="px-6 py-4 font-semibold">API</th>
                  <th className="px-6 py-4 font-semibold">Credits per call</th>
                  <th className="px-6 py-4 font-semibold">Estimated cost (Pro)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E8F0] font-sans">
                {pricingTable.map((row, idx) => (
                  <tr
                    key={row.api}
                    className={idx % 2 === 1 ? "bg-[#F8FAFC]" : "bg-white"}
                  >
                    <td className="px-6 py-4 font-medium text-slate-900 font-mono text-xs">{row.api}</td>
                    <td className="px-6 py-4 text-slate-600 font-mono text-xs">{row.credits}</td>
                    <td className="px-6 py-4 text-slate-800 font-mono text-xs">{row.cost}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <HelpCircle className="w-8 h-8 text-[#2563EB] mx-auto mb-3" />
            <h2 className="text-2xl font-bold text-[#0F172A] tracking-tight">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-4">
            {faqItems.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div
                  key={index}
                  className="border border-[#E2E8F0] bg-white rounded-lg overflow-hidden custom-shadow transition-all duration-200"
                >
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full flex items-center justify-between px-6 py-4 text-left font-semibold text-sm sm:text-base text-[#0F172A] hover:bg-slate-50 transition-colors"
                  >
                    <span>{faq.question}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-slate-500 transition-transform duration-250 ${
                        isOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  <div
                    className={`transition-all duration-200 ease-in-out ${
                      isOpen ? "max-h-96 border-t border-[#E2E8F0] p-6" : "max-h-0 overflow-hidden"
                    }`}
                  >
                    <p className="text-xs sm:text-sm text-[#64748B] leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
