import React from "react";
import Link from "next/link";
import {
  Shield,
  Server,
  Lock,
  Headphones,
  CheckCircle2
} from "lucide-react";
import { cn } from "@/lib/utils";

interface TrustCardProps {
  title: string;
  items: string[];
  icon: React.ReactNode;
  borderClass: string;
}

function TrustCard({ title, items, icon, borderClass }: TrustCardProps) {
  return (
    <div
      className={cn(
        "bg-white border border-[#E2E8F0] rounded-lg p-8 custom-shadow transition-all duration-200 hover:border-slate-350",
        borderClass
      )}
    >
      <div className="flex items-center gap-4 mb-6">
        <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg inline-block">
          {icon}
        </div>
        <h3 className="text-lg font-bold text-[#0F172A] tracking-tight">{title}</h3>
      </div>
      
      <ul className="space-y-4">
        {items.map((item) => (
          <li key={item} className="flex items-start gap-3 text-xs sm:text-sm text-[#64748B]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Trust() {
  return (
    <div className="bg-[#F8FAFC] min-h-screen py-16">
      <div className="max-w-7xl mx-auto px-6">
        {/* Page Header */}
        <div className="text-left max-w-2xl mb-16 pb-12 border-b border-[#E2E8F0]">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0F172A] tracking-tight mb-3">
            Enterprise-grade trust.
          </h1>
          <p className="text-[#64748B] text-sm sm:text-base leading-relaxed">
            Built for engineering teams that cannot afford downtime. Security, compliance, and reliability are core pillars of our architecture.
          </p>
        </div>

        {/* 4 Main Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Security */}
          <TrustCard
            title="Security"
            items={[
              "TLS 1.3 encryption for all data in transit",
              "AES-256 military-grade database encryption at rest",
              "SOC 2 Type II-aligned administrative and operational controls",
              "Zero raw raster imagery stored on local servers"
            ]}
            borderClass="border-l-[4px] border-l-[#2563EB]"
            icon={<Shield className="w-6 h-6 text-[#2563EB]" />}
          />

          {/* Infrastructure */}
          <TrustCard
            title="Infrastructure"
            items={[
              "99.99% uptime guarantee backed by service-level agreements (SLA)",
              "Multi-region data and compute redundancy across AWS availability zones",
              "Sub-500ms P95 global response latency via edge caching",
              "Auto-scaling high-performance geospatial data pipeline"
            ]}
            borderClass="border-l-[4px] border-l-[#06B6D4]"
            icon={<Server className="w-6 h-6 text-[#06B6D4]" />}
          />

          {/* Data Protection */}
          <TrustCard
            title="Data Protection"
            items={[
              "Region-pinned data storage options to comply with local directives",
              "GDPR-ready architecture mapping and data minimization paths",
              "No third-party data sharing or usage without explicit consent",
              "Immutable access logs tracking all administrative queries"
            ]}
            borderClass="border-l-[4px] border-l-[#8B5CF6]"
            icon={<Lock className="w-6 h-6 text-[#8B5CF6]" />}
          />

          {/* Support */}
          <TrustCard
            title="Support"
            items={[
              "24/7/365 infrastructure monitoring and automated paging systems",
              "Prioritized email and Slack channel support for Pro accounts",
              "Dedicated Customer Success Manager (CSM) for Enterprise setups",
              "Contractually guaranteed response time limits (SLA-backed)"
            ]}
            borderClass="border-l-[4px] border-l-[#F59E0B]"
            icon={<Headphones className="w-6 h-6 text-[#F59E0B]" />}
          />
        </div>

        {/* CTA section */}
        <div className="mt-20 border-t border-[#E2E8F0] pt-16 text-center">
          <h2 className="text-2xl font-bold text-[#0F172A] tracking-tight mb-3">
            Ready to build on a platform you can trust?
          </h2>
          <p className="text-[#64748B] text-sm mb-8 max-w-md mx-auto">
            Free sandbox. No credit card required. Production-ready in minutes.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              href="/developers"
              className="bg-[#2563EB] hover:bg-[#1d4ed8] text-white px-6 py-3 rounded-lg text-sm font-medium transition-colors shadow-sm"
            >
              Start Building →
            </Link>
            <Link
              href="/pricing"
              className="border border-slate-300 hover:border-slate-500 text-slate-700 px-6 py-3 rounded-lg text-sm font-medium transition-colors"
            >
              View Pricing
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
