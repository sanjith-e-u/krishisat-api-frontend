import React from "react";
import Link from "next/link";
import {
  Search,
  Map,
  ArrowRight,
  Database,
  Layers,
  Activity,
  Wind
} from "lucide-react";

interface ApiCardProps {
  name: string;
  credits: number;
  description: string;
  endpoint: string;
  method: "GET" | "POST";
  category: string;
}

function ApiCard({ name, credits, description, endpoint, method, category }: ApiCardProps) {
  const isGet = method === "GET";
  
  // Icon selector based on category
  const renderIcon = () => {
    switch (category.toLowerCase()) {
      case "vegetation":
        return <Layers className="w-4 h-4 text-[#2563EB]" />;
      case "water":
        return <Activity className="w-4 h-4 text-[#06B6D4]" />;
      case "weather":
        return <Wind className="w-4 h-4 text-[#64748B]" />;
      default:
        return <Map className="w-4 h-4 text-[#2563EB]" />;
    }
  };

  const iconBg = () => {
    switch (category.toLowerCase()) {
      case "vegetation":
        return "bg-[#2563EB]/10";
      case "water":
        return "bg-[#06B6D4]/10";
      case "weather":
        return "bg-slate-100";
      default:
        return "bg-[#2563EB]/10";
    }
  };

  return (
    <div className="bg-white border border-[#E2E8F0] rounded-lg p-6 hover:shadow-sm transition-all duration-200 flex flex-col justify-between group">
      <div>
        {/* Category Icon */}
        <div className="flex items-center justify-between mb-4">
          <div className={`w-8 h-8 rounded-lg ${iconBg()} flex items-center justify-center`}>
            {renderIcon()}
          </div>
          <span className="bg-slate-100 border border-slate-200 text-slate-600 font-mono text-[10px] px-2 py-0.5 rounded-lg font-medium flex items-center gap-1 select-none">
            <span>⚡</span> {credits} {credits === 1 ? "Credit" : "Credits"} / Call
          </span>
        </div>

        {/* API Name */}
        <h3 className="text-base font-bold text-[#0F172A] mb-2 tracking-tight group-hover:text-[#2563EB] transition-colors">
          {name}
        </h3>

        {/* Description (max 2 lines) */}
        <p className="text-[#64748B] text-xs leading-relaxed mb-4 line-clamp-2 h-8">
          {description}
        </p>
      </div>

      <div>
        {/* Endpoint */}
        <div className="bg-slate-50 border border-slate-100 px-3 py-2 rounded-lg text-[11px] font-mono text-slate-600 mb-4 flex items-center gap-2 overflow-x-auto select-all">
          <span className={`font-semibold shrink-0 ${isGet ? "text-emerald-600" : "text-blue-600"}`}>
            {method}
          </span>
          <span className="truncate">{endpoint}</span>
        </div>

        {/* View Docs Link */}
        <Link
          href="/developers"
          className="text-[#2563EB] hover:text-[#1d4ed8] text-xs font-semibold inline-flex items-center gap-1 transition-colors"
        >
          View Docs <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
        </Link>
      </div>
    </div>
  );
}

export default function Marketplace() {
  return (
    <div className="bg-[#F8FAFC] min-h-screen py-16">
      <div className="max-w-7xl mx-auto px-6">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-[#E2E8F0] mb-16">
          <div className="text-left">
            <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0F172A] tracking-tight mb-2">
              API Marketplace
            </h1>
            <p className="text-[#64748B] text-sm sm:text-base max-w-xl">
              Browse and integrate satellite, weather, and farm intelligence APIs into your workflow.
            </p>
          </div>
          {/* Decorative Search Bar */}
          <div className="relative w-full max-w-xs shrink-0 select-none">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="text"
              placeholder="Search coming soon..."
              disabled
              className="block w-full pl-9 pr-4 py-2 border border-[#E2E8F0] rounded-lg bg-white text-xs text-slate-400 placeholder-slate-400 focus:outline-none cursor-not-allowed shadow-sm"
            />
          </div>
        </div>

        {/* CATEGORY 1: Crop Health Intelligence */}
        <section className="mb-20">
          {/* Accent Strip */}
          <div className="h-[6px] w-full bg-gradient-to-r from-[#EF4444] via-[#FBBF24] to-[#22C55E] rounded-full mb-6" />
          <div className="mb-8">
            <h2 className="text-xl font-bold text-[#0F172A] tracking-tight">Crop Health Intelligence</h2>
            <p className="text-[#64748B] text-xs mt-1">
              Spectral indices for vegetation monitoring, chlorophyll estimation, and crop stress detection.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <ApiCard
              name="NDVI — Normalized Difference Vegetation Index"
              credits={2}
              description="Real-time and historical vegetation health maps for any registered polygon."
              endpoint="/v1/vegetation/ndvi"
              method="GET"
              category="vegetation"
            />
            <ApiCard
              name="NDRE — Red Edge Index"
              credits={2}
              description="Chlorophyll content mapping and early stress detection using red-edge bands."
              endpoint="/v1/vegetation/ndre"
              method="GET"
              category="vegetation"
            />
            <ApiCard
              name="SAVI — Soil Adjusted Vegetation Index"
              credits={2}
              description="Vegetation index corrected for background soil brightness in sparse canopy fields."
              endpoint="/v1/vegetation/savi"
              method="GET"
              category="vegetation"
            />
            <ApiCard
              name="CI — Chlorophyll Index"
              credits={3}
              description="Leaf-level chlorophyll estimation to drive precise nitrogen management decisions."
              endpoint="/v1/vegetation/ci"
              method="GET"
              category="vegetation"
            />
          </div>
        </section>

        {/* CATEGORY 2: Water Intelligence */}
        <section className="mb-20">
          <div className="border border-slate-200 rounded-lg p-6 bg-white overflow-hidden relative mb-8">
            <div className="absolute inset-0 opacity-[0.05] bg-[#06B6D4] pointer-events-none" />
            <h2 className="text-xl font-bold text-[#0F172A] tracking-tight">Water Intelligence</h2>
            <p className="text-[#64748B] text-xs mt-1">
              Moisture dynamics and water stress indices derived from multi-spectral satellite sensor bands.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ApiCard
              name="NDMI — Normalized Difference Moisture Index"
              credits={2}
              description="Canopy water content monitoring. Detects drought stress before it is visible."
              endpoint="/v1/water/ndmi"
              method="GET"
              category="water"
            />
            <ApiCard
              name="NDWI — Normalized Difference Water Index"
              credits={2}
              description="Surface water detection, pond outline mapping, and irrigation path boundaries."
              endpoint="/v1/water/ndwi"
              method="GET"
              category="water"
            />
          </div>
        </section>

        {/* CATEGORY 3: Weather Intelligence */}
        <section className="mb-20">
          <div className="border border-slate-200 rounded-lg p-6 bg-white overflow-hidden relative mb-8">
            <div className="absolute inset-0 opacity-[0.03] bg-slate-800 pointer-events-none" />
            <h2 className="text-xl font-bold text-[#0F172A] tracking-tight">Weather Intelligence</h2>
            <p className="text-[#64748B] text-xs mt-1">
              Hyperlocal meteorological data and temperature accumulators indexed to your registered farm polygons.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ApiCard
              name="Weather API"
              credits={1}
              description="Temperature, rainfall, relative humidity, wind speed, and growing-degree days. Updated every 3 hours."
              endpoint="/v1/weather"
              method="GET"
              category="weather"
            />
          </div>
        </section>

        {/* CATEGORY 4: Farm Management */}
        <section className="mb-8">
          <div className="border border-slate-200 rounded-lg p-6 bg-white overflow-hidden relative mb-8">
            <div className="absolute inset-0 opacity-[0.04] bg-[#2563EB] pointer-events-none" />
            <h2 className="text-xl font-bold text-[#0F172A] tracking-tight">Farm Management</h2>
            <p className="text-[#64748B] text-xs mt-1">
              Core platform infrastructure APIs to register polygons and orchestrate automated tile indexing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ApiCard
              name="Farm Registration"
              credits={1}
              description="POST a GeoJSON polygon boundary to register a farm and generate a stable farm_id for downstream telemetry."
              endpoint="/v1/farms"
              method="POST"
              category="core"
            />
          </div>
        </section>
      </div>
    </div>
  );
}
