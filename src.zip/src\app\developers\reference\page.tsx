import React from "react";
import Link from "next/link";
import { ArrowRight, Terminal, Layers, Activity, CloudRain } from "lucide-react";

interface EndpointInfo {
  method: string;
  path: string;
  credits: number;
  title: string;
  description: string;
  fields: { name: string; type: string; req: boolean; desc: string }[];
}

const endpoints: EndpointInfo[] = [
  {
    method: "POST",
    path: "/v1/farms",
    credits: 1,
    title: "Farm Registration",
    description: "Register a farm polygon boundary once to retrieve a unique, stable farm_id reference.",
    fields: [
      { name: "farm_name", type: "string", req: true, desc: "Human-readable label for the farm." },
      { name: "polygon", type: "GeoJSON", req: true, desc: "Standard GeoJSON polygon coordinates of the field boundary." },
      { name: "metadata", type: "object", req: false, desc: "Optional key-value object containing custom developer metadata." }
    ]
  },
  {
    method: "POST",
    path: "/v1/vegetation/ndvi",
    credits: 2,
    title: "NDVI — Normalized Difference Vegetation Index",
    description: "Measure live green vegetation density and overall crop health from multi-spectral bands.",
    fields: [
      { name: "farm_id", type: "string", req: true, desc: "Target registered farm ID reference." },
      { name: "date", type: "string", req: false, desc: "Optional ISO-8601 query date. Defaults to the latest satellite pass." }
    ]
  },
  {
    method: "POST",
    path: "/v1/water/ndmi",
    credits: 2,
    title: "NDMI — Normalized Difference Moisture Index",
    description: "Analyze crop canopy water stress and vegetation moisture content levels.",
    fields: [
      { name: "farm_id", type: "string", req: true, desc: "Target registered farm ID reference." },
      { name: "date", type: "string", req: false, desc: "Optional ISO-8601 query date. Defaults to the latest satellite pass." }
    ]
  },
  {
    method: "POST",
    path: "/v1/vegetation/ndre",
    credits: 2,
    title: "NDRE — Red Edge Index",
    description: "Detect early chlorophyll variations and nitrogen stress in dense crop canopies.",
    fields: [
      { name: "farm_id", type: "string", req: true, desc: "Target registered farm ID reference." },
      { name: "date", type: "string", req: false, desc: "Optional ISO-8601 query date. Defaults to the latest satellite pass." }
    ]
  },
  {
    method: "POST",
    path: "/v1/vegetation/savi",
    credits: 2,
    title: "SAVI — Soil Adjusted Vegetation Index",
    description: "Measure plant health in sparse crops or early-stage growth where bare soil influences NDVI.",
    fields: [
      { name: "farm_id", type: "string", req: true, desc: "Target registered farm ID reference." },
      { name: "date", type: "string", req: false, desc: "Optional ISO-8601 query date. Defaults to the latest satellite pass." }
    ]
  },
  {
    method: "POST",
    path: "/v1/water/ndwi",
    credits: 2,
    title: "NDWI — Normalized Difference Water Index",
    description: "Detect open water bodies, waterlogging events, and surface irrigation presence.",
    fields: [
      { name: "farm_id", type: "string", req: true, desc: "Target registered farm ID reference." },
      { name: "date", type: "string", req: false, desc: "Optional ISO-8601 query date. Defaults to the latest satellite pass." }
    ]
  },
  {
    method: "POST",
    path: "/v1/vegetation/ci",
    credits: 3,
    title: "CI — Chlorophyll Index",
    description: "Direct estimate of absolute canopy chlorophyll content correlated to crop nitrogen status.",
    fields: [
      { name: "farm_id", type: "string", req: true, desc: "Target registered farm ID reference." },
      { name: "date", type: "string", req: false, desc: "Optional ISO-8601 query date. Defaults to the latest satellite pass." }
    ]
  },
  {
    method: "POST",
    path: "/v1/weather",
    credits: 1,
    title: "Weather Intelligence",
    description: "Hyperlocal atmospheric metrics including temperature, rainfall, humidity, wind, and growing degree days.",
    fields: [
      { name: "farm_id", type: "string", req: true, desc: "Target registered farm ID reference." }
    ]
  }
];

export default function ReferencePage() {
  return (
    <div className="bg-[#F8FAFC] min-h-screen">
      <div className="max-w-4xl mx-auto px-6 py-16">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-[#64748B] mb-8">
          <Link href="/developers" className="hover:text-[#2563EB] transition-colors focus:outline-none focus:ring-2 focus:ring-[#2563EB] rounded px-1">
            Developers
          </Link>
          <span className="text-[#E2E8F0]">/</span>
          <span className="text-[#0F172A] font-medium">API Reference</span>
        </div>

        {/* Hero Header */}
        <div className="mb-12 border-b border-[#E2E8F0] pb-8">
          <span className="text-[10px] uppercase tracking-widest font-mono text-[#2563EB] mb-3 block">
            API Specification
          </span>
          <h1 className="text-4xl font-bold tracking-tight text-[#0F172A] mb-4">
            API Reference
          </h1>
          <p className="text-lg text-[#64748B] leading-relaxed max-w-2xl">
            Explore complete input schemas, request parameters, and credit costs for all 8 active agricultural intelligence endpoints.
          </p>
        </div>

        {/* Endpoints List */}
        <div className="space-y-12">
          {endpoints.map((endpoint) => (
            <div key={endpoint.path} className="bg-white border border-[#E2E8F0] rounded-lg p-8 custom-shadow">
              {/* Badge Header */}
              <div className="flex flex-wrap items-center gap-2 mb-6">
                <span className="font-mono text-xs bg-[#2563EB] text-white px-2 py-1 rounded-lg font-semibold">
                  {endpoint.method}
                </span>
                <span className="font-mono text-sm text-[#0F172A] font-semibold">
                  {endpoint.path}
                </span>
                <span className="font-mono text-xs bg-[#F8FAFC] border border-[#E2E8F0] text-[#64748B] px-2 py-1 rounded-lg ml-auto">
                  {endpoint.credits} {endpoint.credits === 1 ? "credit" : "credits"}
                </span>
              </div>

              {/* Title & Description */}
              <h3 className="text-lg font-bold text-[#0F172A] mb-2">
                {endpoint.title}
              </h3>
              <p className="text-sm text-[#64748B] leading-relaxed mb-6">
                {endpoint.description}
              </p>

              {/* Field Schema Table */}
              <div className="overflow-x-auto border border-[#E2E8F0] rounded-lg">
                <table className="w-full text-sm border-collapse">
                  <thead>
                    <tr className="bg-[#F8FAFC] border-b border-[#E2E8F0]">
                      <th className="text-left py-3 px-4 font-mono text-xs uppercase tracking-widest text-[#64748B]">Parameter</th>
                      <th className="text-left py-3 px-4 font-mono text-xs uppercase tracking-widest text-[#64748B]">Type</th>
                      <th className="text-left py-3 px-4 font-mono text-xs uppercase tracking-widest text-[#64748B]">Required</th>
                      <th className="text-left py-3 px-4 font-mono text-xs uppercase tracking-widest text-[#64748B]">Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    {endpoint.fields.map((field) => (
                      <tr key={field.name} className="border-b border-[#E2E8F0] last:border-b-0 hover:bg-[#F8FAFC]/50">
                        <td className="py-3 px-4 font-mono text-[#0F172A] text-xs font-semibold">{field.name}</td>
                        <td className="py-3 px-4 text-[#64748B] text-xs">{field.type}</td>
                        <td className="py-3 px-4 text-xs">
                          {field.req ? (
                            <span className="text-emerald-600 font-semibold">Yes</span>
                          ) : (
                            <span className="text-slate-400">No</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-[#64748B] text-xs">{field.desc}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>

        {/* Footer CTA */}
        <div className="mt-16 bg-[#0F172A] rounded-lg p-8 text-center">
          <h2 className="text-xl font-bold tracking-tight text-white mb-2">
            Ready to integrate?
          </h2>
          <p className="text-sm text-slate-400 leading-relaxed mb-6 max-w-sm mx-auto">
            Test these request payloads in real-time by walking through our quickstart guide.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <Link
              href="/developers/quickstart"
              className="bg-[#2563EB] hover:bg-[#1d4ed8] text-white px-6 py-3 rounded-lg text-sm font-medium transition-colors shadow-sm inline-flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:ring-offset-2"
            >
              Start Quickstart <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/developers"
              className="border border-slate-600 hover:border-slate-400 text-slate-300 hover:text-white px-6 py-3 rounded-lg text-sm font-medium transition-colors bg-transparent focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2"
            >
              Developer Hub
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
