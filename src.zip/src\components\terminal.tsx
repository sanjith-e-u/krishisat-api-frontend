import React from "react";

export default function Terminal() {
  return (
    <div
      className="rounded-xl border border-slate-700 overflow-hidden shadow-2xl shadow-black/50 select-none font-mono w-full max-w-lg mx-auto md:mx-0"
      style={{ filter: "drop-shadow(0 0 40px rgba(6,182,212,0.08))" }}
    >
      {/* Top Bar */}
      <div className="bg-slate-800 px-4 py-3 flex items-center justify-between border-b border-slate-900">
        <div className="flex items-center gap-1.5 w-1/4">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500 inline-block"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-green-500 inline-block"></span>
        </div>
        <div className="text-xs text-slate-400 font-mono tracking-wide truncate max-w-[200px] sm:max-w-none">
          POST /v1/intelligence
        </div>
        <div className="flex justify-end w-1/4">
          <span className="bg-green-500/10 text-green-400 text-[10px] px-2 py-0.5 rounded font-mono font-medium border border-green-500/20">
            200 OK
          </span>
        </div>
      </div>

      {/* Body */}
      <div className="bg-[#0D1117] p-6 text-sm leading-relaxed overflow-x-auto text-left">
        <pre className="font-mono text-xs sm:text-sm">
          <span className="text-slate-600">{"{"}</span>
          {"\n  "}
          <span className="text-slate-400">"farm_id"</span>
          <span className="text-slate-600">:</span>{" "}
          <span className="text-emerald-400">"KR-1024"</span>
          <span className="text-slate-600">,</span>
          {"\n  "}
          <span className="text-slate-400">"ndvi"</span>
          <span className="text-slate-600">:</span>{" "}
          <span className="text-amber-400">0.82</span>
          <span className="text-slate-600">,</span>
          {"\n  "}
          <span className="text-slate-400">"ndmi"</span>
          <span className="text-slate-600">:</span>{" "}
          <span className="text-amber-400">0.67</span>
          <span className="text-slate-600">,</span>
          {"\n  "}
          <span className="text-slate-400">"weather"</span>
          <span className="text-slate-600">:</span>{" "}
          <span className="text-slate-600">{"{"}</span>
          {"\n    "}
          <span className="text-slate-400">"temp"</span>
          <span className="text-slate-600">:</span>{" "}
          <span className="text-amber-400">29</span>
          <span className="text-slate-600">,</span>
          {"\n    "}
          <span className="text-slate-400">"rainfall"</span>
          <span className="text-slate-600">:</span>{" "}
          <span className="text-amber-400">12</span>
          {"\n  "}
          <span className="text-slate-600">{"}"}</span>
          <span className="text-slate-600">,</span>
          {"\n  "}
          <span className="text-slate-400">"status"</span>
          <span className="text-slate-600">:</span>{" "}
          <span className="text-emerald-400">"success"</span>
          <span className="text-slate-600">,</span>
          {"\n  "}
          <span className="text-slate-400">"latency"</span>
          <span className="text-slate-600">:</span>{" "}
          <span className="text-emerald-400">"420ms"</span>
          {"\n"}
          <span className="text-slate-600">{"}"}</span>
        </pre>
      </div>

      {/* Footer Status Bar */}
      <div className="bg-slate-900 px-4 py-2.5 flex justify-between border-t border-slate-800/80 text-[10px] text-slate-500 font-mono">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          <span className="text-slate-400">live</span>
        </div>
        <div>region: ap-south-1</div>
        <div className="hidden sm:block">req_id: 8c1a…f0d2</div>
      </div>
    </div>
  );
}
