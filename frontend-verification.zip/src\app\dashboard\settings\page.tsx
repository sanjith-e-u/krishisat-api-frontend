"use client"

import React, { useState } from "react"
import DashboardLayout from "@/components/dashboard/layout"
import { User, Building, Settings, Bell, Check, ShieldAlert, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"

type TabType = "profile" | "company" | "api" | "notifications"

export default function DashboardSettings() {
  const [activeTab, setActiveTab] = useState<TabType>("profile")
  const [toastMessage, setToastMessage] = useState<string | null>(null)

  // Profile Form States
  const [profile, setProfile] = useState({
    name: "Dev Agronomist",
    email: "dev@krishisat.org",
    role: "Senior Systems Engineer"
  })

  // Company Form States
  const [company, setCompany] = useState({
    name: "KrishiSat Agritech",
    region: "North India (New Delhi)",
    crops: "Wheat, Paddy, Mustard",
    slug: "krishisat-agritech"
  })

  // API Config States
  const [apiConfig, setApiConfig] = useState({
    cacheEnabled: true,
    cacheTtl: "60",
    webhookUrl: "https://api.krishisat.org/v1/telemetry-hook",
    verboseLogging: false
  })

  // Notification States
  const [notifications, setNotifications] = useState({
    usageAlert: true,
    invoicePaid: true,
    outageAlert: true,
    newsletter: false
  })

  const showToast = (msg: string) => {
    setToastMessage(msg)
    setTimeout(() => setToastMessage(null), 3000)
  }

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault()
    showToast("Profile settings saved successfully!")
  }

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault()
    showToast("Workspace details updated!")
  }

  const handleSaveApi = (e: React.FormEvent) => {
    e.preventDefault()
    showToast("API performance parameters configured!")
  }

  const handleSaveNotifications = (e: React.FormEvent) => {
    e.preventDefault()
    showToast("Notification rules updated!")
  }

  const tabs = [
    { id: "profile", label: "Developer Profile", icon: User },
    { id: "company", label: "Company & Workspace", icon: Building },
    { id: "api", label: "API & Performance", icon: Settings },
    { id: "notifications", label: "Alert Rules", icon: Bell }
  ]

  return (
    <DashboardLayout>
      <div className="space-y-8 select-none relative max-w-4xl">
        
        {/* Toast Notification */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-55 bg-slate-900 border border-slate-800 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 animate-in slide-in-from-bottom-5">
            <div className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
            <span className="text-xs font-semibold">{toastMessage}</span>
          </div>
        )}

        {/* Page Header */}
        <div className="border-b border-slate-200 pb-6">
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Workspace Settings</h1>
          <p className="text-sm text-slate-505 mt-1">Configure profile coordinates, API parameters, caching rules, and event triggers.</p>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 overflow-x-auto gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon
            const isActive = activeTab === tab.id
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={cn(
                  "flex items-center gap-2 px-4 py-3.5 border-b-2 text-xs font-semibold transition-all whitespace-nowrap focus:outline-none",
                  isActive
                    ? "border-[#14532D] text-[#14532D]"
                    : "border-transparent text-slate-500 hover:text-slate-900"
                )}
              >
                <Icon className={cn("w-4 h-4", isActive ? "text-[#14532D]" : "text-slate-400")} />
                <span>{tab.label}</span>
              </button>
            )
          })}
        </div>

        {/* Tab Panels */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
          
          {/* Tab 1: Profile */}
          {activeTab === "profile" && (
            <form onSubmit={handleSaveProfile} className="space-y-6">
              <div className="border-b border-slate-100 pb-4 mb-4">
                <h3 className="text-sm font-bold text-slate-900">Developer Profile</h3>
                <p className="text-xs text-slate-400 mt-0.5">Manage your personal developer account details.</p>
              </div>

              {/* Grid Form */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="devName" className="text-xs font-semibold text-slate-700">Full Name</label>
                  <input
                    id="devName"
                    type="text"
                    required
                    value={profile.name}
                    onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#14532D]/10 focus:border-[#14532D] transition-all"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label htmlFor="devEmail" className="text-xs font-semibold text-slate-700">Account Email</label>
                  <input
                    id="devEmail"
                    type="email"
                    required
                    value={profile.email}
                    onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#14532D]/10 focus:border-[#14532D] transition-all"
                  />
                </div>

                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label htmlFor="devRole" className="text-xs font-semibold text-slate-700">Team Role</label>
                  <input
                    id="devRole"
                    type="text"
                    required
                    value={profile.role}
                    onChange={(e) => setProfile({ ...profile, role: e.target.value })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#14532D]/10 focus:border-[#14532D] transition-all"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="h-10 bg-[#14532D] hover:bg-[#114524] text-white px-5 rounded-lg text-xs font-bold transition-all shadow-sm focus:outline-none"
                >
                  Save Profile Settings
                </button>
              </div>
            </form>
          )}

          {/* Tab 2: Company */}
          {activeTab === "company" && (
            <form onSubmit={handleSaveCompany} className="space-y-6">
              <div className="border-b border-slate-100 pb-4 mb-4">
                <h3 className="text-sm font-bold text-slate-900">Workspace & Organization</h3>
                <p className="text-xs text-slate-400 mt-0.5">Customize properties matching your regional crop registries.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="companyName" className="text-xs font-semibold text-slate-700">Company Name</label>
                  <input
                    id="companyName"
                    type="text"
                    required
                    value={company.name}
                    onChange={(e) => setCompany({ ...company, name: e.target.value })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#14532D]/10 focus:border-[#14532D] transition-all"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label htmlFor="workspaceSlug" className="text-xs font-semibold text-slate-700">Workspace Slug</label>
                  <input
                    id="workspaceSlug"
                    type="text"
                    required
                    value={company.slug}
                    onChange={(e) => setCompany({ ...company, slug: e.target.value })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-205 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-[#14532D]/10 focus:border-[#14532D] transition-all"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label htmlFor="cropTypes" className="text-xs font-semibold text-slate-700">Primary Monitored Crop Types</label>
                  <input
                    id="cropTypes"
                    type="text"
                    placeholder="e.g. Wheat, Rice, Cotton"
                    value={company.crops}
                    onChange={(e) => setCompany({ ...company, crops: e.target.value })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#14532D]/10 focus:border-[#14532D] transition-all"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label htmlFor="monitoredRegion" className="text-xs font-semibold text-slate-700">Geographic Region Scope</label>
                  <input
                    id="monitoredRegion"
                    type="text"
                    value={company.region}
                    onChange={(e) => setCompany({ ...company, region: e.target.value })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#14532D]/10 focus:border-[#14532D] transition-all"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="h-10 bg-[#14532D] hover:bg-[#114524] text-white px-5 rounded-lg text-xs font-bold transition-all shadow-sm focus:outline-none"
                >
                  Update Organization
                </button>
              </div>
            </form>
          )}

          {/* Tab 3: API & Performance */}
          {activeTab === "api" && (
            <form onSubmit={handleSaveApi} className="space-y-6">
              <div className="border-b border-slate-100 pb-4 mb-4">
                <h3 className="text-sm font-bold text-slate-900">API Speed & Performance Hooks</h3>
                <p className="text-xs text-slate-400 mt-0.5">Control calculation caches and event message logs.</p>
              </div>

              {/* Cache Enabled Toggle */}
              <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-100 rounded-lg">
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Activate Telemetry Index Cache</h4>
                  <p className="text-[10px] text-slate-450 leading-relaxed mt-0.5">
                    Caches sensory calculations for overlapping query footprints to save credits.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setApiConfig({ ...apiConfig, cacheEnabled: !apiConfig.cacheEnabled })}
                  className={cn(
                    "w-11 h-6 rounded-full relative transition-colors focus:outline-none",
                    apiConfig.cacheEnabled ? "bg-[#22C55E]" : "bg-slate-300"
                  )}
                >
                  <span
                    className={cn(
                      "w-4 h-4 bg-white rounded-full absolute top-1 transition-all shadow-sm",
                      apiConfig.cacheEnabled ? "left-6" : "left-1"
                    )}
                  />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="cacheTtl" className="text-xs font-semibold text-slate-700">Cache Footprint TTL (Minutes)</label>
                  <input
                    id="cacheTtl"
                    type="number"
                    value={apiConfig.cacheTtl}
                    onChange={(e) => setApiConfig({ ...apiConfig, cacheTtl: e.target.value })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-[#14532D]/10 focus:border-[#14532D] transition-all"
                    disabled={!apiConfig.cacheEnabled}
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label htmlFor="webhookUrl" className="text-xs font-semibold text-slate-700">Event Webhook Endpoint</label>
                  <input
                    id="webhookUrl"
                    type="url"
                    value={apiConfig.webhookUrl}
                    onChange={(e) => setApiConfig({ ...apiConfig, webhookUrl: e.target.value })}
                    className="w-full h-10 px-3 text-sm bg-white border border-slate-200 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-[#14532D]/10 focus:border-[#14532D] transition-all"
                  />
                </div>
              </div>

              {/* Verbose Sandbox Logs Toggle */}
              <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-100 rounded-lg">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 font-sans">Sandbox Verbose Payload Outlets</h4>
                  <p className="text-[10px] text-slate-450 leading-relaxed mt-0.5">
                    Include full atmospheric scattering and cloud cover metadata in query returns.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setApiConfig({ ...apiConfig, verboseLogging: !apiConfig.verboseLogging })}
                  className={cn(
                    "w-11 h-6 rounded-full relative transition-colors focus:outline-none",
                    apiConfig.verboseLogging ? "bg-[#22C55E]" : "bg-slate-300"
                  )}
                >
                  <span
                    className={cn(
                      "w-4 h-4 bg-white rounded-full absolute top-1 transition-all shadow-sm",
                      apiConfig.verboseLogging ? "left-6" : "left-1"
                    )}
                  />
                </button>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="h-10 bg-[#14532D] hover:bg-[#114524] text-white px-5 rounded-lg text-xs font-bold transition-all shadow-sm focus:outline-none"
                >
                  Save API Configuration
                </button>
              </div>
            </form>
          )}

          {/* Tab 4: Notifications */}
          {activeTab === "notifications" && (
            <form onSubmit={handleSaveNotifications} className="space-y-6">
              <div className="border-b border-slate-100 pb-4 mb-4">
                <h3 className="text-sm font-bold text-slate-900">Email Notification Rules</h3>
                <p className="text-xs text-slate-400 mt-0.5">Control when KrishiSat emits account events to your inbox.</p>
              </div>

              <div className="space-y-4">
                {/* Rule 1: Quota threshold */}
                <div className="flex items-start justify-between py-3 border-b border-slate-100 last:border-0">
                  <div className="pr-4">
                    <h4 className="text-xs font-bold text-slate-900">Index Credit Quota Alert</h4>
                    <p className="text-[10px] text-slate-450 leading-relaxed mt-0.5">
                      Notify me immediately when monthly remaining credits decline below 20%.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setNotifications({ ...notifications, usageAlert: !notifications.usageAlert })}
                    className={cn(
                      "w-11 h-6 rounded-full relative transition-colors shrink-0 focus:outline-none",
                      notifications.usageAlert ? "bg-[#22C55E]" : "bg-slate-300"
                    )}
                  >
                    <span
                      className={cn(
                        "w-4 h-4 bg-white rounded-full absolute top-1 transition-all shadow-sm",
                        notifications.usageAlert ? "left-6" : "left-1"
                      )}
                    />
                  </button>
                </div>

                {/* Rule 2: Invoices */}
                <div className="flex items-start justify-between py-3 border-b border-slate-100 last:border-0">
                  <div className="pr-4">
                    <h4 className="text-xs font-bold text-slate-900">Successful Billing Statements</h4>
                    <p className="text-[10px] text-slate-450 leading-relaxed mt-0.5">
                      Email structured receipt logs and download-ready PDF invoice links.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setNotifications({ ...notifications, invoicePaid: !notifications.invoicePaid })}
                    className={cn(
                      "w-11 h-6 rounded-full relative transition-colors shrink-0 focus:outline-none",
                      notifications.invoicePaid ? "bg-[#22C55E]" : "bg-slate-300"
                    )}
                  >
                    <span
                      className={cn(
                        "w-4 h-4 bg-white rounded-full absolute top-1 transition-all shadow-sm",
                        notifications.invoicePaid ? "left-6" : "left-1"
                      )}
                    />
                  </button>
                </div>

                {/* Rule 3: Outages */}
                <div className="flex items-start justify-between py-3 border-b border-slate-100 last:border-0">
                  <div className="pr-4">
                    <h4 className="text-xs font-bold text-slate-900">Sensor Network Interferences</h4>
                    <p className="text-[10px] text-slate-450 leading-relaxed mt-0.5">
                      Alert immediately if orbital schedules or telemetry APIs register outages.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setNotifications({ ...notifications, outageAlert: !notifications.outageAlert })}
                    className={cn(
                      "w-11 h-6 rounded-full relative transition-colors shrink-0 focus:outline-none",
                      notifications.outageAlert ? "bg-[#22C55E]" : "bg-slate-300"
                    )}
                  >
                    <span
                      className={cn(
                        "w-4 h-4 bg-white rounded-full absolute top-1 transition-all shadow-sm",
                        notifications.outageAlert ? "left-6" : "left-1"
                      )}
                    />
                  </button>
                </div>

                {/* Rule 4: Newsletter */}
                <div className="flex items-start justify-between py-3 border-b border-slate-100 last:border-0">
                  <div className="pr-4">
                    <h4 className="text-xs font-bold text-slate-900">Product Logs & Math Grids Releases</h4>
                    <p className="text-[10px] text-slate-450 leading-relaxed mt-0.5">
                      Receive monthly digests describing orbital vector enhancements and new indexes.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setNotifications({ ...notifications, newsletter: !notifications.newsletter })}
                    className={cn(
                      "w-11 h-6 rounded-full relative transition-colors shrink-0 focus:outline-none",
                      notifications.newsletter ? "bg-[#22C55E]" : "bg-slate-300"
                    )}
                  >
                    <span
                      className={cn(
                        "w-4 h-4 bg-white rounded-full absolute top-1 transition-all shadow-sm",
                        notifications.newsletter ? "left-6" : "left-1"
                      )}
                    />
                  </button>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="h-10 bg-[#14532D] hover:bg-[#114524] text-white px-5 rounded-lg text-xs font-bold transition-all shadow-sm focus:outline-none"
                >
                  Save Notification Rules
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </DashboardLayout>
  )
}
